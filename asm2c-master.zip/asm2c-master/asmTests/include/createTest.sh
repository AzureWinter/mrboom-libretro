rm *.o;make test INCLUDEMAIN=1 DEBUG=1 OBJECTS=include.o TARGET_NAME=include
