rm *.o;make OBJECTS=array.o TARGET_NAME=array
