rm *.o;make OBJECTS=vbl.o TARGET_NAME=vbl
