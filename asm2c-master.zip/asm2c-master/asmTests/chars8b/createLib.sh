rm *.o;make OBJECTS=chars8b.o TARGET_NAME=chars8b
echo retroarch -L ./chars8b_libretro.so
