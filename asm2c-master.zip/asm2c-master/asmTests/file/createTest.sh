rm *.o;make test INCLUDEMAIN=1 DEBUG=1 OBJECTS=file.o TARGET_NAME=file
