rm *.o;make OBJECTS=file.o TARGET_NAME=file
