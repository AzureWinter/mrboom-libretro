rm *.o;make OBJECTS=movsb.o TARGET_NAME=movsb
