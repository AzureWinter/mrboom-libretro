rm *.o;make OBJECTS=test.o TARGET_NAME=test
