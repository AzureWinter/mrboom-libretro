rm *.o;make test INCLUDEMAIN=1 DEBUG=1 OBJECTS=test.o TARGET_NAME=test
