rm *.o;make OBJECTS=shlshr.o TARGET_NAME=shlshr
