rm *.o;make OBJECTS=xor.o TARGET_NAME=xor
