rm *.o;make OBJECTS=pushpop.o TARGET_NAME=pushpop
