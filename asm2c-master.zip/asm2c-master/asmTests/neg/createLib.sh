rm *.o;make OBJECTS=neg.o TARGET_NAME=neg
