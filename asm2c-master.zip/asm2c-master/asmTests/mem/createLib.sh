rm *.o;make OBJECTS=mem.o TARGET_NAME=mem
