rm *.o;make OBJECTS=hello.o TARGET_NAME=hello
