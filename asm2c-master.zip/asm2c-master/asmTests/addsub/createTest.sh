rm *.o;make test INCLUDEMAIN=1 DEBUG=1 OBJECTS=addsub.o TARGET_NAME=addsub
