rm *.o;make OBJECTS=addsub.o TARGET_NAME=addsub
