rm *.o;make test INCLUDEMAIN=1 DEBUG=1 OBJECTS=loop.o TARGET_NAME=loop
